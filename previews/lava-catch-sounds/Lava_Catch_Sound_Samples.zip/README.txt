Original synthesized lava-fishing catch sound concepts.
44.1 kHz mono PCM WAV, 1.4 seconds each.
01 Ember pop: brief pop with a light hiss.
02 Molten sizzle: fuller pop, crackle and bubbling.
03 Obsidian chime: lava pop with a bright reward chime.
04 Bubbling catch: rising bubbles followed by a pop.
These are preview concepts, not recordings of Minecraft sounds.
